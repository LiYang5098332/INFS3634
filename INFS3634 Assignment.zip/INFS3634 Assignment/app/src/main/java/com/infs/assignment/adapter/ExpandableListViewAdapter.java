package com.infs.assignment.adapter;

import java.util.ArrayList;
import java.util.HashMap;


import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseExpandableListAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.infs.assignment.R;

public class ExpandableListViewAdapter extends BaseExpandableListAdapter {
    public String[] group = { "Notes","Assignment sample" };
    public String[][] gridViewChild = {
            { "Ch.4 enterprise information system ERP CRM SCM", "Ch.5 How information systems support managerial work and decision making",
                    "Ch.6 Foundation of business intelligence Databases and information management", "Ch.7 Building information system", "Ch.10 information systems security and controls",
                    "Ch.11 Web 2.0Technologies and Business Models" },

            { "INFS1602 GROUP SP-M11B-20", "NFS1602 Assignment A" } };
    LayoutInflater mInflater;
    Context context;

    public ExpandableListViewAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
        this.context = context;
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return gridViewChild[groupPosition][childPosition];
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {
        if (convertView == null) {
            mViewChild = new ViewChild();
            convertView = mInflater.inflate(
                    R.layout.item_listview, parent,false);
            mViewChild.list_item =  convertView
                    .findViewById(R.id.list_item);
            convertView.setTag(mViewChild);
        } else {
            mViewChild = (ViewChild) convertView.getTag();
        }
        mViewChild.list_item .setText(gridViewChild[groupPosition][childPosition]);
        return convertView;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return gridViewChild[groupPosition].length;
    }

    @Override
    public Object getGroup(int groupPosition) {
        return group[groupPosition];
    }

    @Override
    public int getGroupCount() {
        return group.length;
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {
        if (convertView == null) {
            mViewChild = new ViewChild();
            convertView = mInflater.inflate(
                    R.layout.item_type, null);
            mViewChild.textView = (TextView) convertView
                    .findViewById(R.id.channel_group_name);
            mViewChild.imageView = (ImageView) convertView
                    .findViewById(R.id.channel_imageview_orientation);
            convertView.setTag(mViewChild);
        } else {
            mViewChild = (ViewChild) convertView.getTag();
        }

        if (isExpanded) {
            mViewChild.imageView
                    .setImageResource(R.drawable.top);
        } else {
            mViewChild.imageView
                    .setImageResource(R.drawable.down);
        }
        mViewChild.textView.setText(getGroup(groupPosition).toString());
        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    ViewChild mViewChild;

    static class ViewChild {
        ImageView imageView;
        TextView textView;
        TextView list_item;
    }
}
