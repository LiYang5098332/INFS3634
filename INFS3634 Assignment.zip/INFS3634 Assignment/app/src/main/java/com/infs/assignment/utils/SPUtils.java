package com.infs.assignment.utils;

import android.content.Context;
import android.content.SharedPreferences;
public class SPUtils {
	
	private static final String SP_NAME = "sp";
	private static SharedPreferences sp;
	public static void saveInt(Context context,String key,int value){
		sp = context.getSharedPreferences(SP_NAME,0);
		sp.edit().putInt(key, value).commit();
	}
	
	public static int getInt(Context context,String key,int value){
		if(sp==null){
			 sp = context.getSharedPreferences(SP_NAME,0);
		}
		return sp.getInt(key, 0);
	}
	


	
}
