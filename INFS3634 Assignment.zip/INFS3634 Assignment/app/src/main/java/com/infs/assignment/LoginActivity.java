package com.infs.assignment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.infs.assignment.db.UserDB;
import com.infs.assignment.utils.SPUtils;


public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText etName;
    private EditText etPwd;
    private TextView btLogin;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        init();
    }

    private void init() {
        etName = findViewById(R.id.et_name);
        etPwd = findViewById(R.id.et_pwd);
        btLogin = findViewById(R.id.bt_login);
        View tvRegister = findViewById(R.id.tv_register);
        btLogin.setOnClickListener(this);
        tvRegister.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.bt_login:
                String name=etName.getText().toString().trim();
                String pass=etPwd.getText().toString().trim();
                int result= UserDB.getInstance(getApplicationContext()).login(pass,name);
                if (result==-2){
                    Toast.makeText(LoginActivity.this,"username not found",Toast.LENGTH_SHORT).show();
                }else if(result==-1){
                    Toast.makeText(LoginActivity.this,"wrong password",Toast.LENGTH_SHORT).show();
                }else{
                    SPUtils.saveInt(LoginActivity.this,"id",result);
                    Toast.makeText(LoginActivity.this,"login successfully",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(LoginActivity.this,HomeActivity.class));
                }
                break;
            case R.id.tv_register:
                startActivity(new Intent(LoginActivity.this,RegisterActivity.class));
                break;
        }
    }
}
