package com.infs.assignment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.infs.assignment.adapter.BoardAdapter;
import com.infs.assignment.bean.Question;

import java.util.ArrayList;

public class BarActivity extends BaseActivity {
    private ListView listview;
    private ArrayList<Question> list;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bar);
        onSetTitle("discussion board ");
        initData();
        initView();
    }

    private void initData() {
        list = new ArrayList<>();
        list.add(new Question("what are core business processes? ","1"));
        list.add(new Question("What are the core and support activities of a value chain?","2"));
        list.add(new Question("Why are information systems so essential for running and managing a business today? ","3"));
        list.add(new Question("How does Porter's competitive forces model help companies develop competitive strategies using information systems?","4"));
        list.add(new Question("How are information systems transforming business, and what is their relationship to globalization?","5"));
        list.add(new Question("Which features o f organizations do managers need to know about to build and use information systems successfully?","6"));
    }

    private void initView() {
        listview = findViewById(R.id.listview);
        BoardAdapter adapter = new BoardAdapter(this,list);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent();
                intent.setClass(BarActivity.this,DiscussDetailActivity.class);
                intent.putExtra("id",list.get(position).getId());
                startActivity(intent);
            }
        });
    }
}
