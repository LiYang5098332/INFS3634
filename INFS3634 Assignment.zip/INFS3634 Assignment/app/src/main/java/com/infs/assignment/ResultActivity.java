package com.infs.assignment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;


public class ResultActivity extends BaseActivity{
    private TextView tv_num;
    private TextView tv_fs;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        onSetTitle("result");
        int yes = getIntent().getIntExtra("yes", 0);
        tv_num = findViewById(R.id.tv_num);
        tv_fs = findViewById(R.id.tv_fs);
        tv_num.setText("Correct:"+yes);
        tv_fs.setText("mark:"+2*yes);
    }
}
