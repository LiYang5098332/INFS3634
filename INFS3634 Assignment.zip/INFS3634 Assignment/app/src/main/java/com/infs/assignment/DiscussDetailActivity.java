package com.infs.assignment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.infs.assignment.adapter.CommentAdapter;
import com.infs.assignment.db.CommentDB;
import com.infs.assignment.db.CommentItem;

import org.w3c.dom.Comment;

import java.util.ArrayList;
import java.util.List;



public class DiscussDetailActivity extends BaseActivity implements View.OnClickListener {


    private String id;
    private ArrayList<CommentItem> data = new ArrayList<>();
    private CommentAdapter commentAdapter;
    private SwipeRefreshLayout swiperefreshlayout;
    private EditText et_msg;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discuss);
        onSetTitle("detail");
        id = getIntent().getStringExtra("id");
        initView();
    }
    @Override
    protected void onResume() {
        super.onResume();
        initData();
    }


    private void initData() {
        data.clear();
        CommentDB commentHelp = new CommentDB(this);
        List<CommentItem> list = commentHelp.findComment(id);
        for (CommentItem item:
                list ) {
            data.add(item);
        }
        commentAdapter.notifyDataSetChanged();
        swiperefreshlayout.setRefreshing(false);
    }

    private void initView() {
        swiperefreshlayout = findViewById(R.id.swiperefreshlayout);
        ListView listview = findViewById(R.id.listview);
        commentAdapter = new CommentAdapter(this, data);
        listview.setAdapter(commentAdapter);
        swiperefreshlayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                initData();
            }
        });
        et_msg = (EditText)findViewById(R.id.et_msg);
        TextView send = (TextView)findViewById(R.id.send);
        send.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        String content = et_msg.getText().toString().trim();
        if(TextUtils.isEmpty(content)){
            return;
        }
        comment(content);
    }
    private void comment(String content) {
       CommentDB commentDB = new CommentDB(this);
       commentDB.dbInsert(id,content,"");
       initData();
    }
}
