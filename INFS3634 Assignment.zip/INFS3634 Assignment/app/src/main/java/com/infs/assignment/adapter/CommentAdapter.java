package com.infs.assignment.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.infs.assignment.R;
import com.infs.assignment.db.CommentItem;
import com.infs.assignment.db.User;
import com.infs.assignment.db.UserDB;
import com.infs.assignment.utils.SPUtils;

import java.util.List;


public class CommentAdapter extends BaseAdapter {

    private User user;
    private Context mContext;
    private LayoutInflater mInflater;
    private List<CommentItem> QuanList;
    public CommentAdapter(Context context, List QuanList) {
        mContext = context;
        this.QuanList = QuanList;
        mInflater = LayoutInflater.from(mContext);
        int id = SPUtils.getInt(context, "id", 0);
        user = UserDB.getInstance(context).loadUser(id);
    }


    @Override
    public int getCount() {
            return  QuanList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public View getView(final int position, View view, ViewGroup container) {
        ViewHolder vh ;
        if (view != null) {
            vh = (ViewHolder) view.getTag();
        } else {
            vh =  new ViewHolder();
            view = mInflater.inflate(R.layout.item_news_summary, container, false);
            vh.avatarView = (ImageView) view.findViewById(R.id.iv_news_summary_photo);
            vh.name = (TextView) view.findViewById(R.id.tv_news_summary_title);
            vh.content = (TextView) view.findViewById(R.id.tv_news_summary_digest);
            vh.timeView = (TextView) view.findViewById(R.id.tv_news_summary_ptime);
            view.setTag(vh);
        }

        vh.avatarView.setImageResource(R.mipmap.default_headimg);
        vh.name.setText(user.getUsername());
        vh.content.setText(QuanList.get(position).getContent());
        vh.timeView.setText(QuanList.get(position).getTime());
        return view;
    }
    static class ViewHolder {
        ImageView avatarView ;
        TextView name;
        TextView content;
        TextView timeView;
    }
}
