package com.infs.assignment;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import com.infs.assignment.bean.Subject;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;


public class ExamActivity extends AppCompatActivity {
    private List<Subject> list = new ArrayList<>();
    private TextView title;
    private  int postion ;
    private RadioButton rl_a;
    private RadioButton rl_b;
    private RadioButton rl_c;
    private RadioButton rl_d;
    private TextView tv_tile;
    private int succeed;
    private int from;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exam);
        from = getIntent().getIntExtra("groupPosition",3);
        initView();
        init(from);
    }
    private void next(){
        postion++;
        handler.sendEmptyMessage(0);
        rl_a.setChecked(false);
        rl_b.setChecked(false);
        rl_c.setChecked(false);
        rl_d.setChecked(false);
    }
    private void initView() {
        tv_tile = findViewById(R.id.tv_tile);
        title  = findViewById(R.id.title);
        rl_a = findViewById(R.id.rl_a);
        rl_b = findViewById(R.id.rl_b);
        rl_c = findViewById(R.id.rl_c);
        rl_d = findViewById(R.id.rl_d);
        Button bt_ok =  findViewById(R.id.bt_ok);
        Button bt_next =  findViewById(R.id.bt_next);
        bt_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (postion!=list.size()-1){
                    AlertDialog.Builder dialog = new AlertDialog.Builder(ExamActivity.this)
                            .setTitle("Tips")
                            .setMessage("Not Finished!")
                            .setPositiveButton("Comfirm", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                }
                            });
                    dialog.create().show();
                }else{
                    AlertDialog.Builder dialog = new AlertDialog.Builder(ExamActivity.this)
                            .setTitle("Tips")
                            .setMessage("Submit?")
                            .setPositiveButton("Comfirm", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    Intent intent = new Intent();
                                    intent.setClass(ExamActivity.this,ResultActivity.class);
                                    intent.putExtra("yes",succeed);
                                    startActivity(intent);
                                }
                            });
                    dialog.create().show();
                }
            }
        });
        bt_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (postion==list.size()-1){
                    Toast.makeText(ExamActivity.this,"Last Question!",Toast.LENGTH_SHORT).show();
                }else{
                    String ans = getAns();
                    if (TextUtils.isEmpty(ans)){
                        Toast.makeText(ExamActivity.this,"Please Choose Answer",Toast.LENGTH_SHORT).show();
                    }else {
                        if (getAns().equals(list.get(postion).getOk())){
                            succeed++;
                        }
                        postion++;
                        handler.sendEmptyMessage(0);
                    }
                }
            }
        });
    }

    private String getAns(){
        if (rl_a.isChecked()){
            return "a";
        }else if (rl_b.isChecked()){
            return "b";
        }else if (rl_c.isChecked()){
            return "c";
        }else if (rl_d.isChecked()){
            return "d";
        }
        return "";
    }
    private void init(int from) {
        String name = "week3.json";
        if (from==3){
            name = "week4.json";
        }
        try {
            InputStream is = getAssets().open(name);
            InputStreamReader inputStreamReader = new InputStreamReader(is,"utf-8");
            BufferedReader bufferedReader=new BufferedReader(inputStreamReader);
            String line;
            StringBuilder stringBuilder=new StringBuilder();
            while ((line=bufferedReader.readLine())!=null){
                stringBuilder.append(line);
            }
            bufferedReader.close();
            inputStreamReader.close();

            JSONArray jsonArray = new JSONObject(stringBuilder.toString()).getJSONArray("bizobj");
            for(int i=0; i< jsonArray.length(); i++){
                JSONObject obj = (JSONObject) jsonArray.get(i);
                list.add(new Subject(obj));
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        handler.sendEmptyMessage(0);
    }
    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 0:
                    if (list.size()>0) {
                        tv_tile.setText((postion+1)+"/"+list.size());
                        title.setText(list.get(postion).getTitle());
                        rl_a.setText("A:"+list.get(postion).getA());
                        rl_b.setText("B:"+list.get(postion).getB());
                        rl_c.setText("C:"+list.get(postion).getC());
                        rl_d.setText("D:"+list.get(postion).getD());
                    }
                    break;
                default:
                    break;
            }
        }
    };

}
