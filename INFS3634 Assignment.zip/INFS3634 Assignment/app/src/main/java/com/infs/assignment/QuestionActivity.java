package com.infs.assignment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ListView;
import com.infs.assignment.adapter.QuesionAdapter;

public class QuestionActivity extends BaseActivity {
    private ListView listview;
    private ExpandableListView mExpandableListView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);
        setContentView(R.layout.activity_lessons);
        onSetTitle("test question");
        initView();
    }

    private void initView() {
        mExpandableListView =  findViewById(R.id.expandableListView);
        QuesionAdapter mExpandableListViewAdapter = new QuesionAdapter(this);
        mExpandableListView.setAdapter(mExpandableListViewAdapter);
        mExpandableListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                if (groupPosition==2){
                    Intent intent = new Intent(QuestionActivity.this,ExamActivity.class);
                    intent.putExtra("groupPosition",groupPosition);
                    startActivity(intent);
                }else if (groupPosition==3){
                    Intent intent = new Intent(QuestionActivity.this,ExamActivity.class);
                    intent.putExtra("groupPosition",groupPosition);
                    startActivity(intent);
                }
                return false;
            }
        });
    }
}
