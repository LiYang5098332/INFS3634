package com.infs.assignment.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.HashMap;


public class UserDB {

    public static final String DB_NAME = "user";

    public static final int VERSION = 1;

    private static UserDB userDB;

    private SQLiteDatabase db;

    private UserDB(Context context) {
        OpenHelper dbHelper = new OpenHelper(context, DB_NAME, null, VERSION);
        db = dbHelper.getWritableDatabase();
    }

    public synchronized static UserDB getInstance(Context context) {
        if (userDB == null) {
            userDB = new UserDB(context);
        }
        return userDB;
    }

    public ContentValues getContentValues(User user){
        ContentValues cv = new ContentValues();
        cv.put("username", user.getUsername());
        cv.put("userpwd", user.getUserpwd());
        cv.put("email", user.getEmail());
        cv.put("gxqm", user.getGxqm());
        cv.put("mobile", user.getMobile());
        cv.put("age", user.getAge());
        return cv;

    }


    public void updataUser(User user){
        if (user != null) {
          db.update("User",getContentValues(user),"id"+ "= ? ", new String[]{user.getId()+""}) ;
        }
    }

    public int  registerUser(User user) {
        if (user != null) {
            Cursor cursor = db .query("User", null, "username=?", new String[]{user.getUsername().toString()}, null, null, null);
            if (cursor.getCount() > 0) {
                return -1;
            } else {
                try {
                    db.insert("User",null,getContentValues(user));
                } catch (Exception e) {
                    Log.d("fail", e.getMessage().toString());
                }
                return 1;
            }
        }
        else {
            return 0;
        }
    }


    public User loadUser(int id) {
        User user = null;
        Cursor cursor = db .query("User", null, "id"+"="+id, null, null, null, null);
        if(cursor!=null){
            if(cursor.getCount()>0){
                cursor.moveToFirst();
                int id1  = cursor.getInt(cursor.getColumnIndex("id"));
                String username  = cursor.getString(cursor.getColumnIndex("username"));
                String userPwd  = cursor.getString(cursor.getColumnIndex("userpwd"));
                String email  = cursor.getString(cursor.getColumnIndex("email"));
                String mobile  = cursor.getString(cursor.getColumnIndex("mobile"));
                String des  = cursor.getString(cursor.getColumnIndex("gxqm"));
                String age  = cursor.getString(cursor.getColumnIndex("age"));
                user = new User(id1,username,userPwd,email,mobile,age,des);

            }
            cursor.close();
        }
        return user;
    }


    public int login(String pwd,String name){
        HashMap<String,String> hashmap=new HashMap<String,String>();
        Cursor cursor = db .query("User", null, "username=?", new String[]{name}, null, null, null);
        if (cursor.getCount()>0){
            Cursor pwdcursor = db .query("User", null, "userpwd=?"+" and "+"username=?", new String[]{pwd,name
            }, null, null, null);
            if (pwdcursor.getCount()>0){
                cursor.moveToNext();
                return cursor.getInt(cursor.getColumnIndex("id"));
            }else {
                return -1;
            }
        }else {
            return -2;
        }


    }
}
