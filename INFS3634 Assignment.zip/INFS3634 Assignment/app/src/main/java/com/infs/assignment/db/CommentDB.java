package com.infs.assignment.db;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;


import java.util.ArrayList;
import java.util.List;


public class CommentDB {
    private static String DB_NAME = "comment.db";
    private  SqliteHelper dbHelper;
    private  SQLiteDatabase sqliteDatabase;

    public CommentDB(Context context) {
        dbHelper = new SqliteHelper(context, DB_NAME, null, 1 );
    }
    public boolean dbInsert(String id, String content,String time) {
        sqliteDatabase = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("id",id);
        values.put("content", content);
        values.put("time", time);
        long result = sqliteDatabase.insert("comment", null, values);
        //关闭数据库对象
        sqliteDatabase.close();
        if(result != -1){
            return true;
        }else{
            return false;
        }
    }
    public List<CommentItem> findComment(String id){
        List<CommentItem> personList = new ArrayList<CommentItem>();
        SQLiteDatabase database = dbHelper.getReadableDatabase();
        if(database.isOpen()){
            Cursor cursor = database.rawQuery("select * from comment where id=? ",  new String[]{id});
            while(cursor.moveToNext()){
                int idIndex = cursor.getColumnIndex("id");
                int contentIndex = cursor.getColumnIndex("content");
                int timeIndex = cursor.getColumnIndex("time");
                String tid = cursor.getString(idIndex);
                String content = cursor.getString(contentIndex);
                String time = cursor.getString(timeIndex);
                CommentItem  commentItem = new CommentItem(tid,content,time);

                personList.add(commentItem);
            }

        }
        database.close();
        return personList;
    }
}
