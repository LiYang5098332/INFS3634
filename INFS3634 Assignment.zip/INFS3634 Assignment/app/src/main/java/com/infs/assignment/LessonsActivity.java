package com.infs.assignment;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ExpandableListView;

import com.infs.assignment.adapter.ExpandableListViewAdapter;

public class LessonsActivity extends BaseActivity {
    private ExpandableListView mExpandableListView;
    private ExpandableListViewAdapter mExpandableListViewAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lessons);
        onSetTitle("Lessons");
        mExpandableListView =  findViewById(R.id.expandableListView);
        mExpandableListViewAdapter = new ExpandableListViewAdapter(this);
        mExpandableListView.setAdapter(mExpandableListViewAdapter);
        mExpandableListView.expandGroup(0);
        mExpandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                if (groupPosition==0){
                    switch (childPosition){
                        case 0:
                            open("ch4.json");
                            break;
                        case 1:
                            open("ch5.json");
                            break;
                        case 2:
                            open("ch6.json");
                            break;
                        case 3:
                            open("ch7.json");
                            break;
                        case 4:
                            open("ch8.json");
                            break;
                        default:
                            break;
                    }
                }else{
                    switch (childPosition){
                        case 0:
                            goWebViewActivity("INFS1602 GROUP SP-M11B-20","https://www.youtube.com/watch?v=mT46k7u5KuY");
                            break;
                        case 1:
                            goWebViewActivity("NFS1602 Assignment A","https://www.youtube.com/watch?v=J7piP4Os2GE");
                            break;
                        default:
                            break;
                    }
                }

                return true;
            }
        });

    }

    private void goWebViewActivity(String title, String url) {
        Intent intent = new Intent();
        intent.setClass(this,VideoActivity.class);
        intent.putExtra("url",url);
        startActivity(intent);
    }

    private void open(String s) {
        Intent intent = new Intent();
        intent.setClass(this,LessonDetailActivity.class);
        intent.putExtra("s",s);
        startActivity(intent);
    }
}
