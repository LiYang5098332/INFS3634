package com.infs.assignment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.infs.assignment.db.User;
import com.infs.assignment.db.UserDB;


public class RegisterActivity extends BaseActivity implements View.OnClickListener {
    private EditText etName;
    private EditText etPwd;
    private Button btLogin;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        onSetTitle("register");
        init();
    }

    private void init() {
        etName = findViewById(R.id.et_write_name);
        etPwd = findViewById(R.id.et_write_pwd);
        btLogin = findViewById(R.id.btn_login);
        btLogin.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_login:
                String name=etName.getText().toString().trim();
                String pass=etPwd.getText().toString().trim();
                if (TextUtils.isEmpty(name)){
                    onToast("username cannot be empty");
                    return;
                }
                if (TextUtils.isEmpty(pass)){
                    onToast("password cannot be empty");
                    return;
                }
                User user=new User();
                user.setUsername(name);
                user.setUserpwd(pass);
                int result= UserDB.getInstance(getApplicationContext()).registerUser(user);
                if (result==1){
                    Toast.makeText(RegisterActivity.this,"register successfully",Toast.LENGTH_SHORT).show();
                    finish();
                }else  if (result==-1)
                {
                    Toast.makeText(RegisterActivity.this," username already exist",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(RegisterActivity.this,"registration failed",Toast.LENGTH_SHORT).show();
                }

                break;

        }
    }
    public void onToast(String msg) {
        Toast.makeText(this,msg, Toast.LENGTH_SHORT).show();
    }
}
