package com.infs.assignment.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.infs.assignment.R;

public class QuesionAdapter extends BaseExpandableListAdapter {
    public String[] group = { "Week1","Week2","Week 3" ,"Week 4","Week 5"};
    public String[][] gridViewChild = {
            { "How are information systems transforming business, and what is their relationship to globalization? ",
                    "Describe how information systems have changed the " +
                    "way businesses operate and their products and services",
                    "Identify three major new information system trends",
                    "Describe the characteristics of a digital firm",
                    "Describe the challenges and opportunities of globalization in a \"flattened\" world",
                    "Why are information systems so essential for running and managing a business today? " ,
                    "List and describe six reasons why information systems are so important for business today."
            ,"What exactly is an information system? How does it work? What are its management, organization, and technology components? ",
                    "Define an information system and describe the activities it performs. ","List and describe the organizational, management, and technology dimensions of information systems. ",
                    "Distinguish between data and information and between information systems literacy and computer literacy. "},
            {"Which features o f organizations do managers need to know about to build and use information systems successfully? What is the impact o f information systems on organizations?"
            ,"How does Porter's competitive forces model help companies develop competitive strategies using information systems? "

            },
            {},{},{"What are core business processes? ","Describe and contrast order-to-cash, procure-to-pay make-to-stock, and make-to-order business processes"
            ,"What are the core and support activities of a value chain? ","What do you understand by business process management? List some of the terms related to it. "
            ,"Describe what enterprise systems are and how they have evolved ."

    }

    };
    LayoutInflater mInflater;
    Context context;

    public QuesionAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
        this.context = context;
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return gridViewChild[groupPosition][childPosition];
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {
        if (convertView == null) {
            mViewChild = new ViewChild();
            convertView = mInflater.inflate(
                    R.layout.item_question, parent,false);
            mViewChild.list_item =  convertView
                    .findViewById(R.id.list_item);
            convertView.setTag(mViewChild);
        } else {
            mViewChild = (ViewChild) convertView.getTag();
        }
        mViewChild.list_item .setText(gridViewChild[groupPosition][childPosition]);
        return convertView;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return gridViewChild[groupPosition].length;
    }

    @Override
    public Object getGroup(int groupPosition) {
        return group[groupPosition];
    }

    @Override
    public int getGroupCount() {
        return group.length;
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {
        if (convertView == null) {
            mViewChild = new ViewChild();
            convertView = mInflater.inflate(
                    R.layout.item_type, null);
            mViewChild.textView = (TextView) convertView
                    .findViewById(R.id.channel_group_name);
            mViewChild.imageView = (ImageView) convertView
                    .findViewById(R.id.channel_imageview_orientation);
            convertView.setTag(mViewChild);
        } else {
            mViewChild = (ViewChild) convertView.getTag();
        }

        if (isExpanded) {
            mViewChild.imageView
                    .setImageResource(R.drawable.top);
        } else {
            mViewChild.imageView
                    .setImageResource(R.drawable.down);
        }
        mViewChild.textView.setText(getGroup(groupPosition).toString());
        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    ViewChild mViewChild;

    static class ViewChild {
        ImageView imageView;
        TextView textView;
        TextView list_item;
    }
}
