package com.infs.assignment.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.infs.assignment.R;
import com.infs.assignment.bean.Question;

import java.util.List;


public class BoardAdapter extends BaseAdapter {
    public Context context;
    public   List<Question> picList ;
    public BoardAdapter(Context context,  List<Question> picList) {
        this.context = context;
        this.picList = picList;
    }
    @Override
    public int getCount() {
        return picList.size();
    }

    @Override
    public Object getItem(int position) {
        return picList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder vh ;
        if (convertView != null) {
            vh = (ViewHolder) convertView.getTag();
        } else {
            vh =  new ViewHolder();
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_board, parent, false);
            vh.tv_title = (TextView) convertView.findViewById(R.id.tv_title);
            convertView.setTag(vh);
        }
        Question content  = picList.get(position);
        vh.tv_title.setText(content.getTitle());
        return  convertView;
    }
    public class ViewHolder {
        TextView tv_title;
    }
}
