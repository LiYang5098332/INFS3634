package com.infs.assignment;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.infs.assignment.db.User;
import com.infs.assignment.db.UserDB;
import com.infs.assignment.utils.SPUtils;

public class PersonActivity extends BaseActivity implements View.OnClickListener {

    private PersonActivity context;
    private TextView tv_phone;
    private TextView tv_email;
    private TextView tv_des;
    private TextView tv_age;
    private TextView tv_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = this;
        setContentView(R.layout.activity_person);
        onSetTitle("personal profile");
        initView();
    }

    @Override
    protected void onResume() {
        super.onResume();
        int id = SPUtils.getInt(context, "id", 0);
        User user = UserDB.getInstance(PersonActivity.this).loadUser(id);
        tv_name.setText(user.getUsername());
        String phone = user.getMobile();
        if (null!=phone){
            tv_phone.setText(phone);
        }else{
            tv_phone.setText("haven't been set");
        }
        String email = user.getEmail();
        if (null!=email){
            tv_email.setText(email);
        }else{
            tv_email.setText("haven't been set");
        }
        String age = user.getAge();
        if (null!=email){
            tv_age.setText(age);
        }else{
            tv_age.setText("haven't been set");
        }


    }

    private void initView() {
        tv_phone =  findViewById(R.id.tv_phone);
        tv_name =  findViewById(R.id.tv_name);
        tv_des =  findViewById(R.id.tv_des);
        tv_age =  findViewById(R.id.tv_age);
        tv_email =  findViewById(R.id.tv_email);
        RelativeLayout rl_email =  findViewById(R.id.rl_email);
        RelativeLayout rl_age =  findViewById(R.id.rl_age);
        RelativeLayout rl_pwd =  findViewById(R.id.rl_pwd);
        RelativeLayout rl_pic =  findViewById(R.id.rl_pic);
        rl_email.setOnClickListener(this);
        rl_age.setOnClickListener(this);
        rl_pwd.setOnClickListener(this);
        rl_pic.setOnClickListener(this);
        tv_des.setOnClickListener(this);
        RelativeLayout rl_phone =  findViewById(R.id.rl_phone);
        rl_phone.setOnClickListener(this);


    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rl_phone:
                Intent PIntent = new Intent();
                PIntent.setClass(context,ChangeActivity.class);
                PIntent.putExtra("type","phone");
                startActivity(PIntent);
                break;
            case R.id.rl_email:
                Intent eIntent = new Intent();
                eIntent.setClass(context,ChangeActivity.class);
                eIntent.putExtra("type","email");
                startActivity(eIntent);
                break;
            case R.id.rl_pwd:
                Intent passWordIntent = new Intent();
                passWordIntent.setClass(context,ChangeActivity.class);
                passWordIntent.putExtra("type","password");
                startActivity(passWordIntent);
                break;
            case R.id.tv_des:
                Intent DesIntent = new Intent();
                DesIntent.setClass(context,ChangeActivity.class);
                DesIntent.putExtra("type","des");
                startActivity(DesIntent);
                break;
            case R.id.rl_age:
                Intent AgeIntent = new Intent();
                AgeIntent.setClass(context,ChangeActivity.class);
                AgeIntent.putExtra("type","age");
                startActivity(AgeIntent);
                break;


        }
    }


}
