package com.infs.assignment.bean;


import org.json.JSONObject;

public class Subject  {
    public static String ID= "id";
    public static String TITLE= "title";
    public static String A= "a";
    public static String B= "b";
    public static String C= "c";
    public static String D= "d";
    public static String OK= "ok";
    private int id;
    private String title;
    private String a;
    private String b;
    private String c;
    private String d;
    private String ok;

    public Subject(JSONObject obj) {
        id = obj.optInt("id");
        title = obj.optString("title");
        a = obj.optString("a");
        b = obj.optString("b");
        c = obj.optString("c");
        d = obj.optString("d");
        ok = obj.optString("ok");
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Subject() {
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getA() {
        return a;
    }

    public void setA(String a) {
        this.a = a;
    }

    public String getB() {
        return b;
    }

    public void setB(String b) {
        this.b = b;
    }

    public String getC() {
        return c;
    }

    public void setC(String c) {
        this.c = c;
    }

    public String getD() {
        return d;
    }

    public void setD(String d) {
        this.d = d;
    }

    public String getOk() {
        return ok;
    }

    public void setOk(String ok) {
        this.ok = ok;
    }
}
