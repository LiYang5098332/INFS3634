package com.infs.assignment.db;


import java.io.Serializable;


public class CommentItem  implements Serializable {
    public static String ID = "id";
    public static String CONTENT = "content";
    public static String TIME = "time";
    String id;
    String content ;
    String time;

    public CommentItem(String id, String content, String time) {
        this.id = id;
        this.content = content;
        this.time = time;
    }

    public CommentItem() {
    }

    public CommentItem(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
