package com.infs.assignment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RelativeLayout;


public class HomeActivity extends AppCompatActivity implements View.OnClickListener {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    private void initView() {
        RelativeLayout rlPerson = findViewById(R.id.rl_person);
        RelativeLayout rlData = findViewById(R.id.rl_data);
        RelativeLayout rlTest = findViewById(R.id.rl_test);
        RelativeLayout rlDiscuss = findViewById(R.id.rl_discuss);
        rlPerson.setOnClickListener(this);
        rlData.setOnClickListener(this);
        rlTest.setOnClickListener(this);
        rlDiscuss.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.rl_person:
                startActivity(new Intent(HomeActivity.this,PersonActivity.class));
                break;
            case R.id.rl_data:
                startActivity(new Intent(HomeActivity.this,LessonsActivity.class));
                break;
            case R.id.rl_test:
                startActivity(new Intent(HomeActivity.this,QuestionActivity.class));
                break;
            case R.id.rl_discuss:
                startActivity(new Intent(HomeActivity.this,BarActivity.class));
                break;
            default:
                break;
        }
    }
}
