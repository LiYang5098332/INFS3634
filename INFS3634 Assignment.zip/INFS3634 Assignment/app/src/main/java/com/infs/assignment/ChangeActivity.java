package com.infs.assignment;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.infs.assignment.db.User;
import com.infs.assignment.db.UserDB;
import com.infs.assignment.utils.SPUtils;



public class ChangeActivity extends AppCompatActivity {
    TextView atTitle;
    Toolbar atToolbar;
    EditText etWritePwd;
    Button btnLogin;

    private ChangeActivity context;
    private String type;
    private int id;
    private User user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_changepwd);
        initView();
        context = this;
        type = getIntent().getStringExtra("type");
        init();
        id = SPUtils.getInt(context, "id", 0);
        user = UserDB.getInstance(ChangeActivity.this).loadUser(id);
    }

    private void initView() {
        atTitle =  findViewById(R.id.at_title);
        atToolbar =  findViewById(R.id.at_toolbar);
        etWritePwd =  findViewById(R.id.et_write_pwd);
        btnLogin =  findViewById(R.id.btn_login);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pwd = etWritePwd.getText().toString().trim();
                if (type.equals("password")) {
                    if (TextUtils.isEmpty(pwd)) {
                        Toast.makeText(context, "new password cannot be empty", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (pwd.length() < 6 || pwd.length() > 8) {
                        Toast.makeText(context, "Password length should be 6 to 8 digits", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    user.setUserpwd(pwd);
                    UserDB.getInstance(ChangeActivity.this).updataUser(user);
                    Toast.makeText(context, "success", Toast.LENGTH_SHORT).show();
                    finish();
                }
                if (type.equals("phone")){
                    if (TextUtils.isEmpty(pwd)) {
                        Toast.makeText(context, "phone cannot be empty", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    user.setMobile(pwd);
                    UserDB.getInstance(ChangeActivity.this).updataUser(user);
                    Toast.makeText(context, "success", Toast.LENGTH_SHORT).show();
                    finish();
                }
                if (type.equals("email")){
                    if (TextUtils.isEmpty(pwd)) {
                        Toast.makeText(context, "email cannot be empty", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    user.setEmail(pwd);
                    UserDB.getInstance(ChangeActivity.this).updataUser(user);
                    Toast.makeText(context, "success", Toast.LENGTH_SHORT).show();
                    finish();
                }
                if (type.equals("des")){
                    if (TextUtils.isEmpty(pwd)) {
                        Toast.makeText(context, "sign cannot be empty", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    user.setGxqm(pwd);
                    UserDB.getInstance(ChangeActivity.this).updataUser(user);
                    Toast.makeText(context, "success", Toast.LENGTH_SHORT).show();
                    finish();
                }
                if (type.equals("age")){
                    if (TextUtils.isEmpty(pwd)) {
                        Toast.makeText(context, "age cannot be empty", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    user.setAge(pwd);
                    UserDB.getInstance(ChangeActivity.this).updataUser(user);
                    Toast.makeText(context, "success", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }

    /**
     * 根据不同的type,修改不同的title和下面的提示文字
     */
    private void init() {
        switch (type){
            case "phone":
                onSetTitle("change phone");
                etWritePwd.setHint("please enter new phone number");
                break;
            case "email":
                onSetTitle("change email address");
                etWritePwd.setHint("please enter new email address");
                break;
            case "password":
                onSetTitle("change password");
                etWritePwd.setHint("please enter new password");
                break;
            case "des":

                break;
            case "age":
                onSetTitle("change age");
                etWritePwd.setHint("please enter age");
                break;
        }
    }
    public void onSetTitle(String title) {
        Toolbar toolbar =  findViewById(R.id.at_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationIcon(R.drawable.back_arr);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        TextView mTitle =  toolbar.findViewById(R.id.at_title);
        mTitle.setText(title);
    }



}
